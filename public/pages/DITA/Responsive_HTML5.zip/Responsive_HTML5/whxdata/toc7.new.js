(function() {
var toc =  [{"type":"item","name":"Installing a USB Card","url":"Building_a_Computer/t_USBCardInstallation.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();