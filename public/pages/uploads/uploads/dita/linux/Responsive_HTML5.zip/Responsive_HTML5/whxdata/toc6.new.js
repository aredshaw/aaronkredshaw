(function() {
var toc =  [{"type":"item","name":"Installing a Sound Card","url":"Building_a_Computer/t_SoundCardInstallation.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();