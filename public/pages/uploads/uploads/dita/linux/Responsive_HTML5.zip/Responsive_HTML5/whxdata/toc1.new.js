(function() {
var toc =  [{"type":"item","name":"Motherboard Installation","url":"Building_a_Computer/t_MotherboardInstallation.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();