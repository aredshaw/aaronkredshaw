(function() {
var toc =  [{"type":"item","name":"Hard Drive and CD/DVD Drive Installation","url":"Building_a_Computer/t_HardDrive-CD-DVD-Installation.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();