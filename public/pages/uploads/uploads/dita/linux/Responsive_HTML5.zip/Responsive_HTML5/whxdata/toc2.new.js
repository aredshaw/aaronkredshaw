(function() {
var toc =  [{"type":"item","name":"Installing Memory","url":"Building_a_Computer/t_MemoryInstallation.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();