(function() {
var toc =  [{"type":"item","name":"Installing a Network Adapter","url":"Building_a_Computer/t_NetworkCardInstallation.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();