(function() {
var toc =  [{"type":"item","name":"Installing a Graphics Card","url":"Building_a_Computer/t_GraphicsCardInstallation.html"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();